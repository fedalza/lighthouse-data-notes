# f1db

Formula one source data.

This source data comes from http://ergast.com/mrd/db/

Modified for compatibility with PostgreSQL. 

Test on PG v10.

For use with Dimitri Fontaine's 
"Mastering PostgreSQL in Application Development"
